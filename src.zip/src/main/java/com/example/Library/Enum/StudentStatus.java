package com.example.Library.Enum;

public enum StudentStatus {
    Ongoing,
    PassedOut;
}
