package com.example.Library.Enum;

public enum RequestType {
    ISSUE,
    RETURN
}
