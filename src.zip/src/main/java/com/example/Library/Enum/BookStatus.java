package com.example.Library.Enum;

public enum BookStatus {
    AVAILABLE,// -> 0
    NOT_AVAILABLE;// -> 1
}
