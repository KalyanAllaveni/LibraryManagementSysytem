package com.example.Library.Enum;

public enum Request_status {
    Accepted,
    NotAccepted,
    Pending;
}
