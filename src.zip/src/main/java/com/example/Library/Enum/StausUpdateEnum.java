package com.example.Library.Enum;


    public enum StausUpdateEnum{
        Approved,
        Rejected;
    }

