package com.example.Library.Enum;

public enum Transaction_status {
    Completed,
    Rejected;
}
